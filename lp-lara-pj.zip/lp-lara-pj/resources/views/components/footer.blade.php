<footer id="footer">
  <small>Copyright 2019 estra inc. All Rights Reserved.</small>
</footer>