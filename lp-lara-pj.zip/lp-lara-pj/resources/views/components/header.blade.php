<header>
  <div class="flex between">
    <h1 class="header-logo">estra inc.</h1>
    <nav class="header-nav">
      <ul>
        <li><a href="#">home</a></li>
        <li><a href="#">about</a></li>
        <li><a href="#">service</a></li>
        <li><a href="#">works</a></li>
        <li><a href="#">price</a></li>
        <li><a href="#">contact</a></li>
      </ul>
    </nav>
  </div>
</header>