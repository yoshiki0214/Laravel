@extends('layouts.layout')

@section('title','Finish')

@section('main')
    
<main class="finish">
  <h1>送信完了しました</h1>
  <p>ありがとうございます</p>
  <a href="/" class="button">戻る</a>
</main>
@endsection